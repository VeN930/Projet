import sys
import time
from datetime import datetime
from base64 import b64decode
from pathlib import Path
from gvm.connections import UnixSocketConnection
from gvm.errors import GvmError
from gvm.protocols.gmp import Gmp
from gvm.transforms import EtreeCheckCommandTransform, EtreeTransform
from lxml import etree

# Configuration
openvas_socket = '/run/gvmd/gvmd.sock'
openvas_username = 'admin'
openvas_password = '8a557e5b-ce95-4dc3-8421-4ac18d2d4634'
scanner_id = '08b69003-5fc2-4037-a479-93b440211c73'
pdf_report_format_id = "c402cc3e-b531-11e1-9163-406186ea4fc5"
download_directory = '/home/kali/Desktop/Projet/'

def get_task_status(gmp, task_id):
    try:
        response = gmp.get_task(task_id)
        status = response.find('task').find('status').text
        progress = response.find('task').find('progress').text
        return status, progress
    except GvmError as e:
        print("Erreur lors de la récupération de l'état de la tâche:", e)
        return None, None

def parse_response(response):
    return etree.tostring(response, pretty_print=True).decode()

def download_report(gmp, report_id):
    pdf_filename = f"{report_id}.pdf"
    pdf_filepath = Path(download_directory) / pdf_filename

    response = gmp.get_report(report_id=report_id, report_format_id=pdf_report_format_id)
    report_element = response.find("report")
    content = report_element.find("report_format").tail

    if not content:
        print(
            "Le rapport demandé est vide. Soit le rapport ne contient aucun "
            " les résultats ou les outils nécessaires à la création du rapport ne sont "
            " pas installé.",
            file=sys.stderr,
        )
        sys.exit(1)

    binary_base64_encoded_pdf = content.encode("ascii")
    binary_pdf = b64decode(binary_base64_encoded_pdf)
    pdf_filepath.write_bytes(binary_pdf)

    print("Fait. PDF créer: " + str(pdf_filepath))

def create_wizard_scan(target_ip):
    connection = UnixSocketConnection(path=openvas_socket)
    transform = EtreeCheckCommandTransform()

    try:
        with Gmp(connection=connection, transform=transform) as gmp:
            gmp.authenticate(openvas_username, openvas_password)

            current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            port_lists = gmp.get_port_lists()
            port_list_id = next(port_list.get('id') for port_list in port_lists.xpath('//get_port_lists_response/port_list') if port_list.find('name').text == 'All IANA assigned TCP')

            target_name = f"Target-{target_ip}-{current_time}"
            response = gmp.create_target(name=target_name, hosts=[target_ip], port_list_id=port_list_id)
            target_id = response.xpath('//@id')[0]

            scan_configs = gmp.get_scan_configs()
            full_and_fast_id = next(config.get('id') for config in scan_configs.xpath('//get_configs_response/config') if config.find('name').text == 'Full and fast')

            task_name = f"Task-{target_ip}"
            response = gmp.create_task(name=task_name, config_id=full_and_fast_id, target_id=target_id, scanner_id=scanner_id)
            task_id = response.xpath('//@id')[0]

            response = gmp.start_task(task_id)
            print(f"Wizard scan lancer sur {target_ip} avec la task ID: {task_id}")

            while True:
                status, progress = get_task_status(gmp, task_id)
                print(f"Statut de la tâche: {status}, Progrès: {progress}%")
                if status == 'Done':
                    break
                elif status == 'Stopped':
                    print("La tâche a été arrêtée")
                    return
                time.sleep(60)

            print("Analyse terminée. Attendre 2 minutes avant le téléchargement du rapport...")
            time.sleep(120)

            task_response = gmp.get_task(task_id=task_id)
            report_id = task_response.xpath('//last_report/report/@id')[0]

            download_report(gmp, report_id)

    except GvmError as e:
        print('erreur', e, file=sys.stderr)

if __name__ == "__main__":
    print("")
    print("█▀█ █▀█ █▀▀ █▄░█ █░█ ▄▀█ █▀   █▀ █▀▀ ▄▀█ █▄░█")
    print("█▄█ █▀▀ ██▄ █░▀█ ▀▄▀ █▀█ ▄█   ▄█ █▄▄ █▀█ █░▀█")
    print("")
    target_ip = input("Veuillez entrer l'adresse IP cible: ")
    create_wizard_scan(target_ip)