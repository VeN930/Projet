import re
import getpass

def check_password_complexity(password):
    """Vérificatoin de la complexité"""
    length_error = len(password) < 12
    digit_error = re.search(r"\d", password) is None
    uppercase_error = re.search(r"[A-Z]", password) is None
    lowercase_error = re.search(r"[a-z]", password) is None
    symbol_error = re.search(r"[ @!#$%^&*()<>?/\|}{~:]", password) is None

    password_ok = not (length_error or digit_error or uppercase_error or lowercase_error or symbol_error)
    
    return {
        'length_error': length_error,
        'digit_error': digit_error,
        'uppercase_error': uppercase_error,
        'lowercase_error': lowercase_error,
        'symbol_error': symbol_error,
        'password_ok': password_ok
    }

def main():
    print("")
    print("█▀█ ▄▀█ █▀ █▀ █░█░█ █▀█ █▀█ █▀▄   ▀█▀ █▀▀ █▀ ▀█▀")
    print("█▀▀ █▀█ ▄█ ▄█ ▀▄▀▄▀ █▄█ █▀▄ █▄▀   ░█░ ██▄ ▄█ ░█░")
    print("")
    password = getpass.getpass("Entrez votre mot de passe : ")

    result = check_password_complexity(password)
    
    if result['password_ok']:
        print("Le mot de passe est complexe.")
    else:
        print("Le mot de passe n'est pas assez complexe :")
        if result['length_error']:
            print("- Il doit contenir au moins 12 caractères.")
        if result['digit_error']:
            print("- Il doit contenir au moins un chiffre.")
        if result['uppercase_error']:
            print("- Il doit contenir au moins une majuscule.")
        if result['lowercase_error']:
            print("- Il doit contenir au moins une minuscule.")
        if result['symbol_error']:
            print("- Il doit contenir au moins un symbole parmi [ @!#$%^&*()<>?/\|}{~:].")

if __name__ == "__main__":
    main()