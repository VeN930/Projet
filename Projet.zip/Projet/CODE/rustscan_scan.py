import subprocess
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os

def extract_info_from_text(input_text_file):
    with open(input_text_file, "r") as file:
        lines = file.readlines()

    important_info = []
    for line in lines:
        if "open" in line or "Nmap scan report" in line or "MAC Address" in line:
            important_info.append(line.strip())
    
    return important_info

def generate_pdf(extracted_info, output_pdf_file):
    # Créer un document PDF avec ReportLab
    c = canvas.Canvas(output_pdf_file, pagesize=letter)
    width, height = letter

    # Ajouter un titre au PDF
    c.setFont("Helvetica-Bold", 16)
    c.drawString(40, height - 40, "Résultats du Scan RustScan")
    
    # Ajouter les informations extraites
    c.setFont("Helvetica", 12)
    text_object = c.beginText(40, height - 80)
    
    for line in extracted_info:
        text_object.textLine(line)
    
    c.drawText(text_object)
    c.save()

def main():
    # L'utilisateur indique sur quelle adresse IP lancer le scan
    print("")
    print("█▀ █▀▀ ▄▀█ █▄░█   █▀█ █▀█ █▀█ ▀█▀")
    print("▄█ █▄▄ █▀█ █░▀█   █▀▀ █▄█ █▀▄ ░█░")
    print("")
    ip_address = input("Entrez l'adresse IP à scanner : ")

    # Définir les chemins complets des fichiers de sortie
    output_text_file = f"/home/kali/Desktop/Projet/scan_results_{ip_address}.txt"
    output_pdf_file = f"/home/kali/Desktop/Projet/scan_results_{ip_address}.pdf"

    # Construire la commande RustScan avec les options spécifiées et rediriger la sortie vers le fichier texte
    command = f"rustscan -a {ip_address} > {output_text_file}"
    
    try:
        # Lancer le processus pour exécuter RustScan avec la commande spécifiée
        subprocess.run(command, shell=True, check=True)
        print(f"Scan terminé avec succès. Les résultats ont été enregistrés dans {output_text_file}")

        # Extraire les informations importantes du fichier texte
        extracted_info = extract_info_from_text(output_text_file)

        # Convertir les informations extraites en PDF
        generate_pdf(extracted_info, output_pdf_file)
        print(f"Les résultats ont été convertis en PDF et enregistrés dans {output_pdf_file}")

        # Supprimer le fichier texte après la conversion en PDF
        os.remove(output_text_file)
        print(f"Le fichier texte intermédiaire a été supprimé.")

    except subprocess.CalledProcessError as e:
        # En cas d'erreur lors de l'exécution de la commande
        print(f"Erreur : {e}")

if __name__ == "__main__":
    main()