import os

def display_menu():
    os.system('clear' if os.name == 'posix' else 'cls')  # Efface la console pour un affichage du menu plus propre
    print("")
    print("████████╗░█████╗░░█████╗░██╗░░░░░██████╗░░█████╗░██╗░░██╗")
    print("╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔══██╗██╔══██╗╚██╗██╔╝")
    print("░░░██║░░░██║░░██║██║░░██║██║░░░░░██████╦╝██║░░██║░╚███╔╝░")
    print("░░░██║░░░██║░░██║██║░░██║██║░░░░░██╔══██╗██║░░██║░██╔██╗░")
    print("░░░██║░░░╚█████╔╝╚█████╔╝███████╗██████╦╝╚█████╔╝██╔╝╚██╗")
    print("░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝╚═════╝░░╚════╝░╚═╝░░╚═╝")
    print("")
    print("")
    print("")
    print("\nVeuillez choisir un script à exécuter :")
    print("1. Testeur de mot de passe")
    print("2. Scanner de port")
    print("3. Scan de vulnerabilité")
    print("4. Brut force ssh.py")
    print("5. Quitter")
    choice = input("Entrez votre choix (1-5) : ")
    return choice

def run_script(script_name):
    os.system(f'python {script_name}')
    input("\nAppuyez sur Entrée pour continuer...")

def main():
    while True:
        choice = display_menu()
        if choice == '1':
            run_script('passwordtest.py')
        elif choice == '2':
            run_script('rustscan_scan.py')
        elif choice == '3':
            run_script('ScanMachine.py')
        elif choice == '4':
            run_script('sshbrut.py')
        elif choice == '5':
            print("Quitter le programme.")
            break
        else:
            print("Choix invalide. Veuillez réessayer.")

if __name__ == "__main__":
    main()


